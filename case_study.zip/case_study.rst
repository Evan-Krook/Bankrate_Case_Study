.. code:: ipython3

    #Import Statements
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import seaborn as sns
    import copy
    from sklearn import preprocessing 
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split

.. code:: ipython3

    data = pd.read_excel("Pre-Super_Day_candidate_dataset__28candidate_29.xlsx")

.. code:: ipython3

    # Columns not necessary for deciding approval process
    data = data.drop(['User ID', 'applications'], axis = 1)

.. code:: ipython3

    data.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Reason</th>
          <th>Loan_Amount</th>
          <th>FICO_score</th>
          <th>Fico_Score_group</th>
          <th>Employment_Status</th>
          <th>Employment_Sector</th>
          <th>Monthly_Gross_Income</th>
          <th>Monthly_Housing_Payment</th>
          <th>Ever_Bankrupt_or_Foreclose</th>
          <th>Lender</th>
          <th>Approved</th>
          <th>bounty</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>cover_an_unexpected_cost</td>
          <td>100000</td>
          <td>669</td>
          <td>fair</td>
          <td>full_time</td>
          <td>consumer_discretionary</td>
          <td>5024</td>
          <td>927</td>
          <td>0</td>
          <td>B</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>credit_card_refinancing</td>
          <td>70000</td>
          <td>594</td>
          <td>fair</td>
          <td>full_time</td>
          <td>information_technology</td>
          <td>5764</td>
          <td>1177</td>
          <td>0</td>
          <td>B</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>home_improvement</td>
          <td>10000</td>
          <td>596</td>
          <td>fair</td>
          <td>full_time</td>
          <td>information_technology</td>
          <td>4017</td>
          <td>1487</td>
          <td>0</td>
          <td>A</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>home_improvement</td>
          <td>100000</td>
          <td>642</td>
          <td>fair</td>
          <td>part_time</td>
          <td>energy</td>
          <td>3129</td>
          <td>904</td>
          <td>0</td>
          <td>A</td>
          <td>0</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>major_purchase</td>
          <td>30000</td>
          <td>642</td>
          <td>fair</td>
          <td>full_time</td>
          <td>energy</td>
          <td>4220</td>
          <td>1620</td>
          <td>0</td>
          <td>A</td>
          <td>0</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #Replacing values for clearer meaning (Will be changed later)
    replacements = {0:'no',1:'yes'}
    replacements_2 = {0:'no',1:'yes'}
    data['Approved'] = data['Approved'].map(replacements)
    data['Ever_Bankrupt_or_Foreclose'] = data['Ever_Bankrupt_or_Foreclose'].map(replacements_2)

.. code:: ipython3

    data.shape




.. parsed-literal::

    (100000, 12)



.. code:: ipython3

    data.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 100000 entries, 0 to 99999
    Data columns (total 12 columns):
     #   Column                      Non-Null Count   Dtype 
    ---  ------                      --------------   ----- 
     0   Reason                      100000 non-null  object
     1   Loan_Amount                 100000 non-null  int64 
     2   FICO_score                  100000 non-null  int64 
     3   Fico_Score_group            100000 non-null  object
     4   Employment_Status           100000 non-null  object
     5   Employment_Sector           93593 non-null   object
     6   Monthly_Gross_Income        100000 non-null  int64 
     7   Monthly_Housing_Payment     100000 non-null  int64 
     8   Ever_Bankrupt_or_Foreclose  100000 non-null  object
     9   Lender                      100000 non-null  object
     10  Approved                    100000 non-null  object
     11  bounty                      100000 non-null  int64 
    dtypes: int64(5), object(7)
    memory usage: 9.2+ MB
    

**Looking at null values**

**Filling each of the missing Employment Sectors with None value**

**The only column with NAs is Employment_Sector and using the mode to
fill in the NAs**

.. code:: ipython3

    for c in categorical_columns:
        if data[c].isnull().any():
            mode_values = data[c].mode()
            if not mode_values.empty:
                mode_value = mode_values[0]
                data[c].fillna(mode_value, inplace=True)

.. code:: ipython3

    data.isnull().sum().sort_values(ascending=False)




.. parsed-literal::

    Reason                        0
    Loan_Amount                   0
    FICO_score                    0
    Fico_Score_group              0
    Employment_Status             0
    Employment_Sector             0
    Monthly_Gross_Income          0
    Monthly_Housing_Payment       0
    Ever_Bankrupt_or_Foreclose    0
    Lender                        0
    Approved                      0
    bounty                        0
    dtype: int64



.. code:: ipython3

    data.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Reason</th>
          <th>Loan_Amount</th>
          <th>FICO_score</th>
          <th>Fico_Score_group</th>
          <th>Employment_Status</th>
          <th>Employment_Sector</th>
          <th>Monthly_Gross_Income</th>
          <th>Monthly_Housing_Payment</th>
          <th>Ever_Bankrupt_or_Foreclose</th>
          <th>Lender</th>
          <th>Approved</th>
          <th>bounty</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>cover_an_unexpected_cost</td>
          <td>100000</td>
          <td>669</td>
          <td>fair</td>
          <td>full_time</td>
          <td>consumer_discretionary</td>
          <td>5024</td>
          <td>927</td>
          <td>no</td>
          <td>B</td>
          <td>no</td>
          <td>0</td>
        </tr>
        <tr>
          <th>1</th>
          <td>credit_card_refinancing</td>
          <td>70000</td>
          <td>594</td>
          <td>fair</td>
          <td>full_time</td>
          <td>information_technology</td>
          <td>5764</td>
          <td>1177</td>
          <td>no</td>
          <td>B</td>
          <td>no</td>
          <td>0</td>
        </tr>
        <tr>
          <th>2</th>
          <td>home_improvement</td>
          <td>10000</td>
          <td>596</td>
          <td>fair</td>
          <td>full_time</td>
          <td>information_technology</td>
          <td>4017</td>
          <td>1487</td>
          <td>no</td>
          <td>A</td>
          <td>no</td>
          <td>0</td>
        </tr>
        <tr>
          <th>3</th>
          <td>home_improvement</td>
          <td>100000</td>
          <td>642</td>
          <td>fair</td>
          <td>part_time</td>
          <td>energy</td>
          <td>3129</td>
          <td>904</td>
          <td>no</td>
          <td>A</td>
          <td>no</td>
          <td>0</td>
        </tr>
        <tr>
          <th>4</th>
          <td>major_purchase</td>
          <td>30000</td>
          <td>642</td>
          <td>fair</td>
          <td>full_time</td>
          <td>energy</td>
          <td>4220</td>
          <td>1620</td>
          <td>no</td>
          <td>A</td>
          <td>no</td>
          <td>0</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    data.columns




.. parsed-literal::

    Index(['Reason', 'Loan_Amount', 'FICO_score', 'Fico_Score_group',
           'Employment_Status', 'Employment_Sector', 'Monthly_Gross_Income',
           'Monthly_Housing_Payment', 'Ever_Bankrupt_or_Foreclose', 'Lender',
           'Approved', 'bounty'],
          dtype='object')



**Data Engineering New Columns For Better Understanding of Approval
Process**

.. code:: ipython3

    data['Monthly_income_after_housing'] = data['Monthly_Gross_Income'] - data['Monthly_Housing_Payment']
    data['Percentage_income_housing_payment'] = round((data['Monthly_Housing_Payment'] / data['Monthly_Gross_Income'])*100,2)

.. code:: ipython3

    numerical_columns = data.select_dtypes(include='int64').columns
    cateogircal_columns = data.select_dtypes(include='object').columns

.. code:: ipython3

    # Approval vs Non-Approvals
    df_temp = data['Approved'].value_counts()
    plt.pie(df_temp.values,
            labels = df_temp.index,
            autopct = '%1.1f%%')
    plt.title("Percentage of Approvals and Denials")
    plt.show()



.. image:: output_17_0.png


.. code:: ipython3

    data[data['Approved'] =='yes']['Approved'].count()




.. parsed-literal::

    10976



.. code:: ipython3

    total_revenue_all_lenders = data['bounty'].sum()
    print(total_revenue_all_lenders)


.. parsed-literal::

    2641500
    

**Looking at each of the categorical variables aganist the approved
column (Sepearating Charts for sizing purposes)**

.. code:: ipython3

    for j in categorical_columns : 
        a = data[j].value_counts(normalize = True)
        b = a*100
        print(b)


.. parsed-literal::

    debt_conslidation           27.622
    cover_an_unexpected_cost    18.782
    credit_card_refinancing     17.139
    major_purchase              16.023
    home_improvement            11.316
    other                        9.118
    Name: Reason, dtype: float64
    full_time     76.530
    part_time     17.064
    unemployed     6.406
    Name: Employment_Status, dtype: float64
    information_technology    26.155
    health_care               12.403
    real_estate                9.297
    financials                 9.262
    consumer_staples           8.974
    industrials                7.559
    materials                  6.748
    communication_services     6.655
    energy                     5.264
    utilities                  4.536
    consumer_discretionary     3.147
    Name: Employment_Sector, dtype: float64
    no     97.754
    yes     2.246
    Name: Ever_Bankrupt_or_Foreclose, dtype: float64
    fair         36.475
    poor         28.475
    good         27.760
    very_good     5.102
    excellent     2.188
    Name: Fico_Score_group, dtype: float64
    

.. code:: ipython3

    num_plots = len(['Ever_Bankrupt_or_Foreclose', 'Fico_Score_group'])
    fig, axes = plt.subplots(1, num_plots)
    for i, col in enumerate(['Ever_Bankrupt_or_Foreclose', 'Fico_Score_group']):
        sb.countplot(data=data, x=col, hue='Approved', ax=axes[i])
        axes[i].set_xticklabels(axes[i].get_xticklabels(), rotation=45)
    plt.tight_layout() 
    plt.show()



.. image:: output_22_0.png


.. code:: ipython3

    num_plots = len(['Fico_Score_group'])
    fig, axes = plt.subplots(1, num_plots)
    for i, col in enumerate(['Fico_Score_group']):
        sb.countplot(data=data, x=col, hue='Approved', ax=axes)
        axes.set_xticklabels(axes.get_xticklabels(), rotation=85)
        axes.grid(False)
    plt.tight_layout() 
    plt.show()



.. image:: output_23_0.png


.. code:: ipython3

    num_plots = len(['Employment_Status', 'Employment_Sector'])
    fig, axes = plt.subplots(1, num_plots)
    for i, col in enumerate(['Employment_Status','Employment_Sector']):
        sb.countplot(data=data, x=col, hue='Approved', ax=axes[i])
        axes[i].set_xticklabels(axes[i].get_xticklabels(), rotation=85)
    plt.tight_layout() 
    plt.show()



.. image:: output_24_0.png


.. code:: ipython3

    for i in categorical_columns :
        j = pd.crosstab(data['Approved'],data[i],normalize = 'columns')
        print(j)


.. parsed-literal::

    Reason    cover_an_unexpected_cost  credit_card_refinancing  \
    Approved                                                      
    no                        0.890693                 0.887333   
    yes                       0.109307                 0.112667   
    
    Reason    debt_conslidation  home_improvement  major_purchase     other  
    Approved                                                                 
    no                 0.891065          0.890244         0.89047  0.891862  
    yes                0.108935          0.109756         0.10953  0.108138  
    Employment_Status  full_time  part_time  unemployed
    Approved                                           
    no                  0.879289   0.918776    0.945052
    yes                 0.120711   0.081224    0.054948
    Employment_Sector  communication_services  consumer_discretionary  \
    Approved                                                            
    no                               0.904282                0.915793   
    yes                              0.095718                0.084207   
    
    Employment_Sector  consumer_staples    energy  financials  health_care  \
    Approved                                                                 
    no                         0.903165  0.893997    0.867631     0.880271   
    yes                        0.096835  0.106003    0.132369     0.119729   
    
    Employment_Sector  industrials  information_technology  materials  \
    Approved                                                            
    no                    0.882524                0.894399   0.891672   
    yes                   0.117476                0.105601   0.108328   
    
    Employment_Sector  real_estate  utilities  
    Approved                                   
    no                    0.885017   0.892857  
    yes                   0.114983   0.107143  
    Ever_Bankrupt_or_Foreclose        no       yes
    Approved                                      
    no                          0.888547  0.963936
    yes                         0.111453  0.036064
    Fico_Score_group  excellent      fair     good      poor  very_good
    Approved                                                           
    no                 0.542048  0.935627  0.81938  0.972151   0.643473
    yes                0.457952  0.064373  0.18062  0.027849   0.356527
    

**Inital Observations**

-  Lender A saw most success in approving applicants.
-  Almost impossible to be approved if been bankrupt or foreclosed in
   the past.
-  Loan amounts between 10,000 and 30,000 saw the highest approval
   success rate.
-  All Fico credit score groups have a similar approval rate outside of
   good having a higher rate than the rest.
-  Not much varaition in the approval based on reasoning. (A lot more
   people used the reasoning of debt consildation overall)
-  Full-time employment status had a major advantage over part-time and
   unemployed status in loan approval rates.
-  Similar varaiation in approvals through employment sectors with
   information technology seeing a little higher rate than the rest.

**Looking at each of the numerical variables distribution seperating
approvals and rejections (Sepearating Charts for sizing purposes)**

.. code:: ipython3

    for idx,num_col in enumerate(numerical_columns):
        sns.displot(x= num_col,data=data,bins=10)
        plt.show()



.. image:: output_28_0.png



.. image:: output_28_1.png



.. image:: output_28_2.png



.. image:: output_28_3.png



.. image:: output_28_4.png



.. image:: output_28_5.png


.. code:: ipython3

    data_approvals = data[data['Approved'] == 'yes']
    data_rejections = data[data['Approved'] == 'no']

.. code:: ipython3

    plt.figure()
    sb.histplot(data=data_rejections['Monthly_Housing_Payment'], kde=True)
    plt.xlabel('Monthly Housing Payment')
    plt.ylabel('Frequency')
    plt.title('Distribution of Monthly Housing Payment Rejections')
    plt.show()



.. image:: output_30_0.png


.. code:: ipython3

    plt.figure()
    sb.histplot(data=data_approvals['Monthly_Housing_Payment'], kde=True)
    plt.xlabel('Monthly Housing Payment')
    plt.ylabel('Frequency')
    plt.title('Distribution of Monthly Housing Payment Approvals')
    plt.show()



.. image:: output_31_0.png


.. code:: ipython3

    plt.figure() 
    sb.histplot(data=data_rejections['Monthly_Gross_Income'], kde=True)
    plt.xlabel('Monthly Gross Income')
    plt.ylabel('Frequency')
    plt.title('Distribution of Monthyl Gross Income Rejections')
    plt.show()



.. image:: output_32_0.png


.. code:: ipython3

    plt.figure() 
    sb.histplot(data=data_approvals['Monthly_Gross_Income'], kde=True)
    plt.xlabel('Monthly Gross Income')
    plt.ylabel('Frequency')
    plt.title('Distribution of Monthyl Gross Income Approvals')
    plt.show()



.. image:: output_33_0.png


.. code:: ipython3

    plt.figure() 
    sb.histplot(data=data_rejections['FICO_score'], kde=True)
    plt.xlabel('FICO Credit Score')
    plt.ylabel('Frequency')
    plt.title('Distribution of FICO Credit Score Rejections')
    plt.show()



.. image:: output_34_0.png


.. code:: ipython3

    plt.figure() 
    sb.histplot(data=data_approvals['FICO_score'], kde=True)
    plt.xlabel('FICO Credit Score')
    plt.ylabel('Frequency')
    plt.title('Distribution of FICO Credit Score Approvals')
    plt.show()



.. image:: output_35_0.png


.. code:: ipython3

    summary_stats = pd.DataFrame(columns=['Statistic', 'Median', 'Mode', 'Mean'])
    for m in numerical_columns:
        medians = data.groupby('Approved')[m].median()
        modes = data.groupby('Approved')[m].apply(lambda x: x.mode().iloc[0])
        means = data.groupby('Approved')[m].mean()
        summary_stats = summary_stats.append({'Statistic': m,
                                              'Median': round(medians.iloc[0], 1),
                                              'Mode': round(modes.iloc[0], 1),
                                              'Mean': round(means.iloc[0], 1)}, ignore_index=True)
    plt.figure(figsize=(10, 6))
    plt.axis('off')  # Hide axis
    table = plt.table(cellText=summary_stats.values,
                      colLabels=summary_stats.columns,
                      loc='center',
                      cellLoc='center',
                      colColours=['lightgrey']*4,  # Set column color
                      bbox=[0, 0, 1, 1])  # Adjust bounding box to reduce whitespace
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    plt.tight_layout()
    plt.show()


.. parsed-literal::

    C:\Users\ekroo\AppData\Local\Temp\ipykernel_47460\653520769.py:6: FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.
      summary_stats = summary_stats.append({'Statistic': m,
    C:\Users\ekroo\AppData\Local\Temp\ipykernel_47460\653520769.py:6: FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.
      summary_stats = summary_stats.append({'Statistic': m,
    C:\Users\ekroo\AppData\Local\Temp\ipykernel_47460\653520769.py:6: FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.
      summary_stats = summary_stats.append({'Statistic': m,
    C:\Users\ekroo\AppData\Local\Temp\ipykernel_47460\653520769.py:6: FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.
      summary_stats = summary_stats.append({'Statistic': m,
    C:\Users\ekroo\AppData\Local\Temp\ipykernel_47460\653520769.py:6: FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.
      summary_stats = summary_stats.append({'Statistic': m,
    C:\Users\ekroo\AppData\Local\Temp\ipykernel_47460\653520769.py:6: FutureWarning: The frame.append method is deprecated and will be removed from pandas in a future version. Use pandas.concat instead.
      summary_stats = summary_stats.append({'Statistic': m,
    


.. image:: output_36_1.png


**Now Looking at Each of the Lenders Approval Statistics**

.. code:: ipython3

    sum_revenue = data[data['Approved'] == 'yes'].groupby('Lender')['bounty'].sum()
    print(sum_revenue)


.. parsed-literal::

    Lender
    A    1507750
    B     686000
    C     447750
    Name: bounty, dtype: int64
    

.. code:: ipython3

    grouped_df = data.groupby('Lender')['Approved'].value_counts()
    
    # Plot the pie chart for each group
    for group_name, group_data in grouped_df.groupby(level=0):
        plt.figure()
        plt.title(f'Pie Chart for Group: {group_name}')
        plt.pie(group_data.values,
                labels=group_data.index.get_level_values(1),
                autopct='%1.1f%%')
        plt.show()



.. image:: output_39_0.png



.. image:: output_39_1.png



.. image:: output_39_2.png


.. code:: ipython3

    for j in categorical_columns : 
        a = data.groupby('Lender')[j].value_counts(normalize = True)
        b = a*100
        print(b)


.. parsed-literal::

    Lender  Reason                  
    A       debt_conslidation           27.632727
            cover_an_unexpected_cost    18.767273
            credit_card_refinancing     17.167273
            major_purchase              16.007273
            home_improvement            11.278182
            other                        9.147273
    B       debt_conslidation           27.509091
            cover_an_unexpected_cost    18.530909
            credit_card_refinancing     17.352727
            major_purchase              16.072727
            home_improvement            11.341818
            other                        9.192727
    C       debt_conslidation           27.765714
            cover_an_unexpected_cost    19.222857
            credit_card_refinancing     16.714286
            major_purchase              15.994286
            home_improvement            11.394286
            other                        8.908571
    Name: Reason, dtype: float64
    Lender  Employment_Status
    A       full_time            80.163636
            part_time            18.181818
            unemployed            1.654545
    B       full_time            79.807273
            part_time            12.920000
            unemployed            7.272727
    C       full_time            59.960000
            part_time            20.062857
            unemployed           19.977143
    Name: Employment_Status, dtype: float64
    Lender  Employment_Sector     
    A       information_technology    22.461818
            health_care               13.063636
            financials                 9.760000
            real_estate                9.756364
            consumer_staples           9.354545
            industrials                7.989091
            materials                  7.085455
            communication_services     6.961818
            energy                     5.447273
            utilities                  4.823636
            consumer_discretionary     3.296364
    B       information_technology    26.992727
            health_care               12.320000
            financials                 9.207273
            real_estate                8.989091
            consumer_staples           8.970909
            industrials                7.421818
            materials                  6.650909
            communication_services     6.647273
            energy                     5.410909
            utilities                  4.378182
            consumer_discretionary     3.010909
    C       information_technology    36.445714
            health_care               10.457143
            real_estate                8.337143
            consumer_staples           7.782857
            financials                 7.782857
            industrials                6.422857
            materials                  5.840000
            communication_services     5.702857
            energy                     4.457143
            utilities                  3.880000
            consumer_discretionary     2.891429
    Name: Employment_Sector, dtype: float64
    Lender  Ever_Bankrupt_or_Foreclose
    A       no                            97.803636
            yes                            2.196364
    B       no                            98.945455
            yes                            1.054545
    C       no                            95.725714
            yes                            4.274286
    Name: Ever_Bankrupt_or_Foreclose, dtype: float64
    Lender  Fico_Score_group
    A       fair                35.567273
            good                29.105455
            poor                28.441818
            very_good            4.721818
            excellent            2.163636
    B       fair                36.083636
            poor                28.269091
            good                26.909091
            very_good            6.447273
            excellent            2.290909
    C       fair                39.942857
            poor                28.902857
            good                24.868571
            very_good            4.182857
            excellent            2.102857
    Name: Fico_Score_group, dtype: float64
    

.. code:: ipython3

    for col in categorical_columns:
        g = sns.FacetGrid(data, col='Lender', height=5, aspect=1)
        g.map_dataframe(sns.countplot, x=col, hue='Approved', ax=g.axes[0, 0], palette = {'no': 'blue', 'yes': 'orange'})
        g.set_axis_labels(x_var=col)
        g.axes[0, 0].set_title(col)
        g.set_xticklabels(rotation=45)
        g.add_legend(title='Approved')
        for ax, title in zip(g.axes.flat, ['Lender A', 'Lender B', 'Lender C']):
            ax.set_title(title)
    
        plt.tight_layout()
        plt.show()



.. image:: output_41_0.png



.. image:: output_41_1.png



.. image:: output_41_2.png



.. image:: output_41_3.png



.. image:: output_41_4.png


.. code:: ipython3

    for num_col in numerical_columns:
        g = sns.FacetGrid(data, col='Lender', height=5, aspect=1)
        g.map_dataframe(sns.histplot, x=num_col, bins=10)
        g.set_titles('{col_name}')
        plt.tight_layout()
        plt.show()



.. image:: output_42_0.png



.. image:: output_42_1.png



.. image:: output_42_2.png



.. image:: output_42_3.png



.. image:: output_42_4.png



.. image:: output_42_5.png


**Making of Dataset for correlation and predictive model**

.. code:: ipython3

    data_for_model = copy.deepcopy(data)

.. code:: ipython3

    data_for_model['Monthly_income_after_housing'] = data_for_model['Monthly_Gross_Income'] - data_for_model['Monthly_Housing_Payment']
    data_for_model['Percentage_income_housing_payment'] = round((data_for_model['Monthly_Housing_Payment'] / data_for_model['Monthly_Gross_Income'])*100,2)

.. code:: ipython3

    data_for_model.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Reason</th>
          <th>Loan_Amount</th>
          <th>FICO_score</th>
          <th>Fico_Score_group</th>
          <th>Employment_Status</th>
          <th>Employment_Sector</th>
          <th>Monthly_Gross_Income</th>
          <th>Monthly_Housing_Payment</th>
          <th>Ever_Bankrupt_or_Foreclose</th>
          <th>Lender</th>
          <th>Approved</th>
          <th>bounty</th>
          <th>Monthly_income_after_housing</th>
          <th>Percentage_income_housing_payment</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>cover_an_unexpected_cost</td>
          <td>100000</td>
          <td>669</td>
          <td>fair</td>
          <td>full_time</td>
          <td>consumer_discretionary</td>
          <td>5024</td>
          <td>927</td>
          <td>no</td>
          <td>B</td>
          <td>no</td>
          <td>0</td>
          <td>4097</td>
          <td>18.45</td>
        </tr>
        <tr>
          <th>1</th>
          <td>credit_card_refinancing</td>
          <td>70000</td>
          <td>594</td>
          <td>fair</td>
          <td>full_time</td>
          <td>information_technology</td>
          <td>5764</td>
          <td>1177</td>
          <td>no</td>
          <td>B</td>
          <td>no</td>
          <td>0</td>
          <td>4587</td>
          <td>20.42</td>
        </tr>
        <tr>
          <th>2</th>
          <td>home_improvement</td>
          <td>10000</td>
          <td>596</td>
          <td>fair</td>
          <td>full_time</td>
          <td>information_technology</td>
          <td>4017</td>
          <td>1487</td>
          <td>no</td>
          <td>A</td>
          <td>no</td>
          <td>0</td>
          <td>2530</td>
          <td>37.02</td>
        </tr>
        <tr>
          <th>3</th>
          <td>home_improvement</td>
          <td>100000</td>
          <td>642</td>
          <td>fair</td>
          <td>part_time</td>
          <td>energy</td>
          <td>3129</td>
          <td>904</td>
          <td>no</td>
          <td>A</td>
          <td>no</td>
          <td>0</td>
          <td>2225</td>
          <td>28.89</td>
        </tr>
        <tr>
          <th>4</th>
          <td>major_purchase</td>
          <td>30000</td>
          <td>642</td>
          <td>fair</td>
          <td>full_time</td>
          <td>energy</td>
          <td>4220</td>
          <td>1620</td>
          <td>no</td>
          <td>A</td>
          <td>no</td>
          <td>0</td>
          <td>2600</td>
          <td>38.39</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    label_encoder = preprocessing.LabelEncoder() 
    obj = (data_for_model.dtypes == 'object') 
    for col in list(obj[obj].index): 
        data_for_model[col] = label_encoder.fit_transform(data_for_model[col])

.. code:: ipython3

    data_for_model = data_for_model.drop(['bounty'], axis = 1)

.. code:: ipython3

    data_for_model.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Reason</th>
          <th>Loan_Amount</th>
          <th>FICO_score</th>
          <th>Fico_Score_group</th>
          <th>Employment_Status</th>
          <th>Employment_Sector</th>
          <th>Monthly_Gross_Income</th>
          <th>Monthly_Housing_Payment</th>
          <th>Ever_Bankrupt_or_Foreclose</th>
          <th>Lender</th>
          <th>Approved</th>
          <th>Monthly_income_after_housing</th>
          <th>Percentage_income_housing_payment</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>0</td>
          <td>100000</td>
          <td>669</td>
          <td>1</td>
          <td>0</td>
          <td>1</td>
          <td>5024</td>
          <td>927</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>4097</td>
          <td>18.45</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1</td>
          <td>70000</td>
          <td>594</td>
          <td>1</td>
          <td>0</td>
          <td>7</td>
          <td>5764</td>
          <td>1177</td>
          <td>0</td>
          <td>1</td>
          <td>0</td>
          <td>4587</td>
          <td>20.42</td>
        </tr>
        <tr>
          <th>2</th>
          <td>3</td>
          <td>10000</td>
          <td>596</td>
          <td>1</td>
          <td>0</td>
          <td>7</td>
          <td>4017</td>
          <td>1487</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>2530</td>
          <td>37.02</td>
        </tr>
        <tr>
          <th>3</th>
          <td>3</td>
          <td>100000</td>
          <td>642</td>
          <td>1</td>
          <td>1</td>
          <td>3</td>
          <td>3129</td>
          <td>904</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>2225</td>
          <td>28.89</td>
        </tr>
        <tr>
          <th>4</th>
          <td>4</td>
          <td>30000</td>
          <td>642</td>
          <td>1</td>
          <td>0</td>
          <td>3</td>
          <td>4220</td>
          <td>1620</td>
          <td>0</td>
          <td>0</td>
          <td>0</td>
          <td>2600</td>
          <td>38.39</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    cors = data_for_model.corrwith(data_for_model['Approved']).sort_values(ascending=False)
    
    print(cors)


.. parsed-literal::

    Approved                             1.000000
    FICO_score                           0.269587
    Monthly_income_after_housing         0.180581
    Monthly_Gross_Income                 0.171791
    Lender                               0.044778
    Employment_Sector                    0.010742
    Fico_Score_group                     0.010469
    Reason                              -0.001721
    Monthly_Housing_Payment             -0.027558
    Ever_Bankrupt_or_Foreclose          -0.035736
    Loan_Amount                         -0.040089
    Employment_Status                   -0.065473
    Percentage_income_housing_payment   -0.121182
    dtype: float64
    

.. code:: ipython3

    plt.figure()
    sns.barplot(x=cors.index, y=cors, palette='viridis')
    plt.xticks(rotation=90)
    plt.xlabel('Features')
    plt.ylabel('Correlation with Approved')
    plt.title('Top Feature Correlations with Approved')
    plt.show()



.. image:: output_51_0.png


.. code:: ipython3

    correlation_by_lender = {}
    for lender_id in data_for_model['Lender'].unique():
        lender_data = data_for_model[data_for_model['Lender'] == lender_id]
        correlation_with_approved = lender_data.corrwith(lender_data['Approved']).sort_values(ascending=False)
        correlation_by_lender[f'Lender {lender_id}'] = correlation_with_approved
    for lender, correlation in correlation_by_lender.items():
        print(f"Correlation for {lender}:")
        print(correlation)
        print()


.. parsed-literal::

    Correlation for Lender 1:
    Approved                             1.000000
    FICO_score                           0.316949
    Monthly_income_after_housing         0.205955
    Monthly_Gross_Income                 0.197259
    Fico_Score_group                     0.049250
    Employment_Sector                    0.010345
    Reason                               0.006172
    Monthly_Housing_Payment             -0.015656
    Ever_Bankrupt_or_Foreclose          -0.028599
    Loan_Amount                         -0.033155
    Employment_Status                   -0.074227
    Percentage_income_housing_payment   -0.142000
    Lender                                    NaN
    dtype: float64
    
    Correlation for Lender 0:
    Approved                             1.000000
    FICO_score                           0.264852
    Monthly_Gross_Income                 0.185287
    Monthly_income_after_housing         0.185033
    Employment_Sector                    0.021351
    Monthly_Housing_Payment              0.010163
    Fico_Score_group                     0.003234
    Reason                              -0.002625
    Loan_Amount                         -0.034692
    Ever_Bankrupt_or_Foreclose          -0.039489
    Employment_Status                   -0.053640
    Percentage_income_housing_payment   -0.091536
    Lender                                    NaN
    dtype: float64
    
    Correlation for Lender 2:
    Approved                             1.000000
    FICO_score                           0.257962
    Monthly_income_after_housing         0.176196
    Monthly_Gross_Income                 0.162265
    Fico_Score_group                    -0.000728
    Reason                              -0.006208
    Employment_Sector                   -0.031561
    Monthly_Housing_Payment             -0.058433
    Ever_Bankrupt_or_Foreclose          -0.059775
    Loan_Amount                         -0.063958
    Employment_Status                   -0.154547
    Percentage_income_housing_payment   -0.171483
    Lender                                    NaN
    dtype: float64
    
    

**Predictive Model**

-  Going to split the data into the three lenders to get a preidction
   for each of the three
-  Removing the bounty varaible because the price the lender offers for
   approved application will not switch

.. code:: ipython3

    lender_a = data_for_model[data_for_model['Lender'] == 0]
    lender_b = data_for_model[data_for_model['Lender'] == 1]
    lender_c= data_for_model[data_for_model['Lender'] == 2]

.. code:: ipython3

    X_a = lender_a.drop(columns=['Approved'])
    y_a = lender_a['Approved']
    X_b = lender_b.drop(columns=['Approved'])
    y_b = lender_b['Approved']
    X_c = lender_c.drop(columns=['Approved'])
    y_c = lender_c['Approved']

.. code:: ipython3

    Xa_train, Xa_test, ya_train, ya_test = train_test_split(X_a, y_a, test_size=0.2, random_state=42)
    Xb_train, Xb_test, yb_train, yb_test = train_test_split(X_b, y_b, test_size=0.2, random_state=42)
    Xc_train, Xc_test, yc_train, yc_test = train_test_split(X_c, y_c, test_size=0.2, random_state=42)

.. code:: ipython3

    rm_model_a = RandomForestClassifier()
    rm_model_a.fit(Xa_train,ya_train)




.. raw:: html

    <style>#sk-container-id-7 {color: black;}#sk-container-id-7 pre{padding: 0;}#sk-container-id-7 div.sk-toggleable {background-color: white;}#sk-container-id-7 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-7 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-7 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-7 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-7 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-7 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-7 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-7 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-7 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-7 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-7 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-7 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-7 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-7 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-7 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-7 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-7 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-7 div.sk-item {position: relative;z-index: 1;}#sk-container-id-7 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-7 div.sk-item::before, #sk-container-id-7 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-7 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-7 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-7 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-7 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-7 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-7 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-7 div.sk-label-container {text-align: center;}#sk-container-id-7 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-7 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-7" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-7" type="checkbox" checked><label for="sk-estimator-id-7" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div></div></div>



.. code:: ipython3

    feature_importances = rm_model_a.feature_importances_
    importance_df = pd.DataFrame({
        'Feature': Xa_train.columns,
        'Importance': feature_importances
    })
    importance_df = importance_df.sort_values(by='Importance', ascending=False)
    predictions = rm_model_a.predict(Xa_test)
    ideal_customer_index = predictions.argmax()
    ideal_customer = Xa_test.iloc[[ideal_customer_index]]
    ideal_customer_approval_probability = rm_model_a.predict_proba(Xa_test)[ideal_customer_index][1] 
    print("Feature Importance:")
    print(importance_df)
    print("\nIdeal Customer (Variables):")
    print(ideal_customer)
    print("\nProbability of Approval for Ideal Customer:", ideal_customer_approval_probability)


.. parsed-literal::

    Feature Importance:
                                  Feature  Importance
    2                          FICO_score    0.178751
    10       Monthly_income_after_housing    0.153351
    11  Percentage_income_housing_payment    0.148154
    7             Monthly_Housing_Payment    0.147477
    6                Monthly_Gross_Income    0.147330
    1                         Loan_Amount    0.069246
    5                   Employment_Sector    0.065568
    0                              Reason    0.050131
    3                    Fico_Score_group    0.030790
    4                   Employment_Status    0.007082
    8          Ever_Bankrupt_or_Foreclose    0.002120
    9                              Lender    0.000000
    
    Ideal Customer (Variables):
           Reason  Loan_Amount  FICO_score  Fico_Score_group  Employment_Status  \
    62433       2        20000         689                 2                  0   
    
           Employment_Sector  Monthly_Gross_Income  Monthly_Housing_Payment  \
    62433                  0                 18536                     2302   
    
           Ever_Bankrupt_or_Foreclose  Lender  Monthly_income_after_housing  \
    62433                           0       0                         16234   
    
           Percentage_income_housing_payment  
    62433                              12.42  
    
    Probability of Approval for Ideal Customer: 0.68
    

.. code:: ipython3

    rm_model_b = RandomForestClassifier()
    rm_model_b.fit(Xb_train,yb_train)




.. raw:: html

    <style>#sk-container-id-8 {color: black;}#sk-container-id-8 pre{padding: 0;}#sk-container-id-8 div.sk-toggleable {background-color: white;}#sk-container-id-8 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-8 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-8 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-8 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-8 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-8 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-8 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-8 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-8 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-8 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-8 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-8 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-8 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-8 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-8 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-8 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-8 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-8 div.sk-item {position: relative;z-index: 1;}#sk-container-id-8 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-8 div.sk-item::before, #sk-container-id-8 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-8 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-8 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-8 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-8 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-8 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-8 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-8 div.sk-label-container {text-align: center;}#sk-container-id-8 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-8 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-8" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-8" type="checkbox" checked><label for="sk-estimator-id-8" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div></div></div>



.. code:: ipython3

    feature_importances = rm_model_b.feature_importances_
    importance_df = pd.DataFrame({
        'Feature': Xb_train.columns,
        'Importance': feature_importances
    })
    importance_df = importance_df.sort_values(by='Importance', ascending=False)
    predictions = rm_model_b.predict(Xb_test)
    ideal_customer_index = predictions.argmax()
    ideal_customer = Xb_test.iloc[[ideal_customer_index]]
    ideal_customer_approval_probability = rm_model_b.predict_proba(Xb_test)[ideal_customer_index][1] 
    print("Feature Importance:")
    print(importance_df)
    print("\nIdeal Customer (Variables):")
    print(ideal_customer)
    print("\nProbability of Approval for Ideal Customer:", ideal_customer_approval_probability)


.. parsed-literal::

    Feature Importance:
                                  Feature  Importance
    2                          FICO_score    0.212393
    6                Monthly_Gross_Income    0.140998
    11  Percentage_income_housing_payment    0.138412
    10       Monthly_income_after_housing    0.136374
    7             Monthly_Housing_Payment    0.131335
    1                         Loan_Amount    0.068983
    5                   Employment_Sector    0.065517
    0                              Reason    0.049636
    3                    Fico_Score_group    0.048762
    4                   Employment_Status    0.006720
    8          Ever_Bankrupt_or_Foreclose    0.000871
    9                              Lender    0.000000
    
    Ideal Customer (Variables):
           Reason  Loan_Amount  FICO_score  Fico_Score_group  Employment_Status  \
    65734       2        10000         823                 0                  0   
    
           Employment_Sector  Monthly_Gross_Income  Monthly_Housing_Payment  \
    65734                  3                 14054                     2589   
    
           Ever_Bankrupt_or_Foreclose  Lender  Monthly_income_after_housing  \
    65734                           0       1                         11465   
    
           Percentage_income_housing_payment  
    65734                              18.42  
    
    Probability of Approval for Ideal Customer: 0.62
    

.. code:: ipython3

    rm_model_c = RandomForestClassifier()
    rm_model_c.fit(Xc_train,yc_train)




.. raw:: html

    <style>#sk-container-id-9 {color: black;}#sk-container-id-9 pre{padding: 0;}#sk-container-id-9 div.sk-toggleable {background-color: white;}#sk-container-id-9 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-9 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-9 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-9 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-9 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-9 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-9 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-9 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-9 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-9 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-9 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-9 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-9 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-9 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-9 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-9 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-9 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-9 div.sk-item {position: relative;z-index: 1;}#sk-container-id-9 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-9 div.sk-item::before, #sk-container-id-9 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-9 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-9 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-9 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-9 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-9 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-9 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-9 div.sk-label-container {text-align: center;}#sk-container-id-9 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-9 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-9" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-9" type="checkbox" checked><label for="sk-estimator-id-9" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div></div></div>



.. code:: ipython3

    feature_importances = rm_model_c.feature_importances_
    importance_df = pd.DataFrame({
        'Feature': Xc_train.columns,
        'Importance': feature_importances
    })
    importance_df = importance_df.sort_values(by='Importance', ascending=False)
    predictions = rm_model_c.predict(Xc_test)
    ideal_customer_index = predictions.argmax()
    ideal_customer = Xc_test.iloc[[ideal_customer_index]]
    ideal_customer_approval_probability = rm_model_c.predict_proba(Xc_test)[ideal_customer_index][1] 
    print("Feature Importance:")
    print(importance_df)
    print("\nIdeal Customer (Variables):")
    print(ideal_customer)
    print("\nProbability of Approval for Ideal Customer:", ideal_customer_approval_probability)


.. parsed-literal::

    Feature Importance:
                                  Feature  Importance
    2                          FICO_score    0.177984
    11  Percentage_income_housing_payment    0.145522
    7             Monthly_Housing_Payment    0.141109
    6                Monthly_Gross_Income    0.140006
    10       Monthly_income_after_housing    0.137521
    1                         Loan_Amount    0.076934
    5                   Employment_Sector    0.068218
    0                              Reason    0.055743
    3                    Fico_Score_group    0.033293
    4                   Employment_Status    0.019726
    8          Ever_Bankrupt_or_Foreclose    0.003945
    9                              Lender    0.000000
    
    Ideal Customer (Variables):
           Reason  Loan_Amount  FICO_score  Fico_Score_group  Employment_Status  \
    22288       1        10000         599                 1                  0   
    
           Employment_Sector  Monthly_Gross_Income  Monthly_Housing_Payment  \
    22288                  5                  8277                      500   
    
           Ever_Bankrupt_or_Foreclose  Lender  Monthly_income_after_housing  \
    22288                           0       2                          7777   
    
           Percentage_income_housing_payment  
    22288                               6.04  
    
    Probability of Approval for Ideal Customer: 0.65
    
